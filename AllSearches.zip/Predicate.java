// DO NOT MODIFY this file.
// Any modification will incurr into the mark zero for the whole exercise.

interface Predicate<A> {
    public boolean holds(A a);
}

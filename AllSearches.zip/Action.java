
interface Action<A> {
    void apply(A a);
}
